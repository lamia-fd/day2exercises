package com.example.companionobjectsapp

import androidx.constraintlayout.widget.ConstraintLayout

class Background {

    companion object{

    }

    fun changeBackground(layout: ConstraintLayout,day:String){

        if(day=="day"){
            layout.setBackgroundResource(R.drawable.day)
        }else if (day=="night"){
            layout.setBackgroundResource(R.drawable.night)

        }

    }
}