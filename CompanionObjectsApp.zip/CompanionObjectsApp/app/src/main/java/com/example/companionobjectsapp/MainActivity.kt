package com.example.companionobjectsapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.constraintlayout.widget.ConstraintLayout

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var layout=findViewById<ConstraintLayout>(R.id.layout)
        val text=findViewById<EditText>(R.id.editText)
        val but=findViewById<Button>(R.id.button)


but.setOnClickListener {
    var t=text.text.toString().lowercase()

    if(t=="day"){
        Background().changeBackground(layout,"day")
    }else if (t=="night"){
        Background().changeBackground(layout,"night")

    }

}


    }
}