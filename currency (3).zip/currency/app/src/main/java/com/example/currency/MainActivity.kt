package com.example.currency

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.*
import com.example.currency.constant.cur
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var userText = findViewById<EditText>(R.id.editText)
        var date = findViewById<TextView>(R.id.date)
        var button=findViewById<Button>(R.id.button)
        var spinner =findViewById<Spinner>(R.id.spinner)
        var result =findViewById<TextView>(R.id.Result)
        var displayResponse:Double
        var Response=""

        var dateResp=""
        var selection=0


        if(spinner !=null){
            val adapter= ArrayAdapter(this,android.R.layout.simple_spinner_item,cur)
            spinner.adapter=adapter

            spinner.onItemSelectedListener=object :AdapterView.OnItemSelectedListener{
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    selection=position
                }

                override fun onNothingSelected(parent: AdapterView<*>?) {

                }

            }

        }

        val apiInterface = APIClient.getClient()?.create(APIInterface::class.java)

        val call: Call<Details?>? = apiInterface!!.doGetListResources()

        call?.enqueue(object : Callback<Details?> {
            override fun onResponse(
                call: Call<Details?>?,
                response: Response<Details?>
            ) {
                Log.d("TAG", response.code().toString() + "")
                val resource: Details? = response.body()



                when (selection) {
                    0 -> {Response="${resource?.eur?.gbp}" }
                    1 -> {Response="${resource?.eur?.usd}" }
                    2 -> {Response="${resource?.eur?.aud}" }
                    3 -> {Response="${resource?.eur?.sar}" }
                    4 -> {Response="${resource?.eur?.kwd}" }
                    5 -> {Response="${resource?.eur?.jpy}" }
                    6 -> {Response="${resource?.eur?.syp}" }
                }
                 dateResp="${resource?.date}"
            }
            override fun onFailure(call: Call<Details?>, t: Throwable) {
                call.cancel()
            }
        })

        button.setOnClickListener {
            var amount= userText.text.toString()
            var amount1=amount.toDouble()
            var currncy=Response.toDouble()
            displayResponse=amount1 * currncy
            result.text = "Result :${displayResponse}"
            date.text=dateResp
            }
}}