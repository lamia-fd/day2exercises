package com.example.currency

object constant {
     const val URL="https://cdn.jsdelivr.net/gh/fawazahmed0/currency-api@1/latest/currencies/"

    val cur= arrayListOf("GBP","USD","AUD","SAR","KWD","JPI","SYP")




}